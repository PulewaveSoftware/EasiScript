import ply.lex as lex

# Define tokens
tokens = [
    'ID', 'NUMBER', 'STRING', 'PLUS', 'MINUS', 'MULTIPLY', 'DIVIDE', 'LPAREN', 'RPAREN',
    'ASSIGN', 'SEMICOLON', 'COMMA', 'LT', 'GT', 'EQ', 'NOT',
    'IF', 'ELSE', 'ENDIF', 'WHILE', 'ENDWHILE', 'FUNCTION', 'ENDFUNCTION',
    'PRINT', 'DISPLAY', 'SHOW', 'SAY', 'SET', 'SUM_ADD', 'SUM_SUBTRACT', 'PRODUCT_MULTIPLY',
    'DIVISION_DIVIDE', 'RETURN', 'OPEN', 'CLOSE', 'READ', 'ASK', 'CREATE', 'LIST', 'DICT', 
    'LENGTH', 'TO_STRING', 'TO_INTEGER'
]

# Reserved words
reserved = {
    'if': 'IF',
    'else': 'ELSE',
    'endif': 'ENDIF',
    'while': 'WHILE',
    'endwhile': 'ENDWHILE',
    'function': 'FUNCTION',
    'endfunction': 'ENDFUNCTION',
    'print': 'PRINT',
    'display': 'DISPLAY',
    'show': 'SHOW',
    'say': 'SAY',
    'set': 'SET',
    'sum': 'SUM_ADD',
    'subtract': 'SUM_SUBTRACT',
    'product': 'PRODUCT_MULTIPLY',
    'divide': 'DIVISION_DIVIDE',
    'return': 'RETURN',
    'open': 'OPEN',
    'close': 'CLOSE',
    'read': 'READ',
    'ask': 'ASK',
    'create': 'CREATE',
    'list': 'LIST',
    'dict': 'DICT',
    'length': 'LENGTH',
    'to': 'TO_STRING',
    'integer': 'TO_INTEGER',
}

# Tokens definitions
t_PLUS = r'\+'
t_MINUS = r'-'
t_MULTIPLY = r'\*'
t_DIVIDE = r'/'
t_ASSIGN = r'='
t_LT = r'<'
t_GT = r'>'
t_EQ = r'=='
t_NOT = r'!'
t_LPAREN = r'\('
t_RPAREN = r'\)'
t_SEMICOLON = r';'
t_COMMA = r','

# Define literals
literals = ['+', '-', '*', '/', '=', '(', ')', ';', ',']

# Define a string token
def t_STRING(t):
    r'\".*?\"'
    t.value = t.value.strip('"')
    return t

# Define a number token
def t_NUMBER(t):
    r'\d+'
    t.value = int(t.value)
    return t

# Define an identifier token
def t_ID(t):
    r'[a-zA-Z_][a-zA-Z_0-9]*'
    t.type = reserved.get(t.value, 'ID')  # Check for reserved words
    return t

# Define a comment token
def t_COMMENT(t):
    r'\#.*'
    pass  # Ignore comments

# Ignore spaces and tabs
t_ignore = ' \t'

# Define new lines
def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

# Error handling rule
def t_error(t):
    print(f"Illegal character '{t.value[0]}'")
    t.lexer.skip(1)

# Build the lexer
lexer = lex.lex()

# For debugging
if __name__ == "__main__":
    data = '''
    function example():
        set x = 10;
        print "Hello, World!";
    '''
    lexer.input(data)
    for token in lexer:
        print(token)
